﻿namespace pizzatyo
{
	partial class Form1
	{
		/// <summary>
		///  Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		///  Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		///  Required method for Designer support - do not modify
		///  the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			label1 = new Label();
			numericmargarita = new NumericUpDown();
			numericbolognese = new NumericUpDown();
			label2 = new Label();
			numerictropicana = new NumericUpDown();
			label3 = new Label();
			numericopera = new NumericUpDown();
			label4 = new Label();
			numericjupecial = new NumericUpDown();
			label7 = new Label();
			numericAmericano = new NumericUpDown();
			label8 = new Label();
			label9 = new Label();
			label10 = new Label();
			numericPepsi = new NumericUpDown();
			numericUpDown1 = new NumericUpDown();
			label5 = new Label();
			chcmargarita = new CheckBox();
			chcbolognese = new CheckBox();
			chcopera = new CheckBox();
			chctropicana = new CheckBox();
			chcamericano = new CheckBox();
			chcjupe = new CheckBox();
			label6 = new Label();
			chcpekoni = new CheckBox();
			chcKebab = new CheckBox();
			txthinta = new TextBox();
			button1 = new Button();
			button2 = new Button();
			pictureBox1 = new PictureBox();
			label11 = new Label();
			txtKateinen = new TextBox();
			txtRahaaTakaisin = new TextBox();
			label13 = new Label();
			chckateinen = new CheckBox();
			pictureBox2 = new PictureBox();
			pictureBox3 = new PictureBox();
			pictureBox4 = new PictureBox();
			pictureBox5 = new PictureBox();
			txtKassa = new TextBox();
			label12 = new Label();
			button3 = new Button();
			txtKuitti = new TextBox();
			button4 = new Button();
			label14 = new Label();
			pictureBox6 = new PictureBox();
			pictureBox7 = new PictureBox();
			pictureBox8 = new PictureBox();
			label15 = new Label();
			((System.ComponentModel.ISupportInitialize)numericmargarita).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericbolognese).BeginInit();
			((System.ComponentModel.ISupportInitialize)numerictropicana).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericopera).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericjupecial).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericAmericano).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericPepsi).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown1).BeginInit();
			((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
			((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
			((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
			((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
			((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
			((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
			((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
			((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
			SuspendLayout();
			// 
			// label1
			// 
			label1.AutoSize = true;
			label1.Location = new Point(91, 103);
			label1.Name = "label1";
			label1.Size = new Size(91, 15);
			label1.TabIndex = 0;
			label1.Text = "1. Margarita 12€";
			// 
			// numericmargarita
			// 
			numericmargarita.Location = new Point(184, 101);
			numericmargarita.Name = "numericmargarita";
			numericmargarita.Size = new Size(31, 23);
			numericmargarita.TabIndex = 4;
			// 
			// numericbolognese
			// 
			numericbolognese.Location = new Point(184, 172);
			numericbolognese.Name = "numericbolognese";
			numericbolognese.Size = new Size(31, 23);
			numericbolognese.TabIndex = 6;
			// 
			// label2
			// 
			label2.AutoSize = true;
			label2.Location = new Point(91, 174);
			label2.Name = "label2";
			label2.Size = new Size(95, 15);
			label2.TabIndex = 5;
			label2.Text = "2. Bolognese 11€";
			// 
			// numerictropicana
			// 
			numerictropicana.Location = new Point(369, 101);
			numerictropicana.Name = "numerictropicana";
			numerictropicana.Size = new Size(31, 23);
			numerictropicana.TabIndex = 10;
			// 
			// label3
			// 
			label3.AutoSize = true;
			label3.Location = new Point(266, 103);
			label3.Name = "label3";
			label3.Size = new Size(101, 15);
			label3.TabIndex = 9;
			label3.Text = "4. Tropicana 12.5€";
			// 
			// numericopera
			// 
			numericopera.Location = new Point(184, 243);
			numericopera.Name = "numericopera";
			numericopera.Size = new Size(31, 23);
			numericopera.TabIndex = 8;
			// 
			// label4
			// 
			label4.AutoSize = true;
			label4.Location = new Point(71, 245);
			label4.Name = "label4";
			label4.Size = new Size(111, 15);
			label4.TabIndex = 7;
			label4.Text = "3. Opera special 13€";
			// 
			// numericjupecial
			// 
			numericjupecial.Location = new Point(369, 243);
			numericjupecial.Name = "numericjupecial";
			numericjupecial.Size = new Size(31, 23);
			numericjupecial.TabIndex = 14;
			// 
			// label7
			// 
			label7.AutoSize = true;
			label7.Location = new Point(264, 245);
			label7.Name = "label7";
			label7.Size = new Size(103, 15);
			label7.TabIndex = 13;
			label7.Text = "6. Jupe special 15€";
			// 
			// numericAmericano
			// 
			numericAmericano.Location = new Point(369, 172);
			numericAmericano.Name = "numericAmericano";
			numericAmericano.Size = new Size(31, 23);
			numericAmericano.TabIndex = 12;
			// 
			// label8
			// 
			label8.AutoSize = true;
			label8.Location = new Point(269, 174);
			label8.Name = "label8";
			label8.Size = new Size(98, 15);
			label8.TabIndex = 11;
			label8.Text = "5. Americano 14€";
			// 
			// label9
			// 
			label9.AutoSize = true;
			label9.Location = new Point(493, 101);
			label9.Name = "label9";
			label9.Size = new Size(49, 15);
			label9.TabIndex = 20;
			label9.Text = "Juomat:";
			// 
			// label10
			// 
			label10.AutoSize = true;
			label10.Location = new Point(443, 148);
			label10.Name = "label10";
			label10.Size = new Size(99, 15);
			label10.TabIndex = 21;
			label10.Text = "Pepsi Max 1.5L 6€";
			// 
			// numericPepsi
			// 
			numericPepsi.Location = new Point(548, 146);
			numericPepsi.Name = "numericPepsi";
			numericPepsi.Size = new Size(31, 23);
			numericPepsi.TabIndex = 22;
			// 
			// numericUpDown1
			// 
			numericUpDown1.Location = new Point(548, 195);
			numericUpDown1.Name = "numericUpDown1";
			numericUpDown1.Size = new Size(31, 23);
			numericUpDown1.TabIndex = 24;
			// 
			// label5
			// 
			label5.AutoSize = true;
			label5.Location = new Point(443, 197);
			label5.Name = "label5";
			label5.Size = new Size(97, 15);
			label5.TabIndex = 23;
			label5.Text = "CocaCola 1.5L 6€";
			// 
			// chcmargarita
			// 
			chcmargarita.AutoSize = true;
			chcmargarita.Location = new Point(610, 119);
			chcmargarita.Name = "chcmargarita";
			chcmargarita.Size = new Size(77, 19);
			chcmargarita.TabIndex = 26;
			chcmargarita.Text = "Margarita";
			chcmargarita.UseVisualStyleBackColor = true;
			// 
			// chcbolognese
			// 
			chcbolognese.AutoSize = true;
			chcbolognese.Location = new Point(693, 119);
			chcbolognese.Name = "chcbolognese";
			chcbolognese.Size = new Size(81, 19);
			chcbolognese.TabIndex = 27;
			chcbolognese.Text = "Bolognese";
			chcbolognese.UseVisualStyleBackColor = true;
			// 
			// chcopera
			// 
			chcopera.AutoSize = true;
			chcopera.Location = new Point(610, 144);
			chcopera.Name = "chcopera";
			chcopera.Size = new Size(58, 19);
			chcopera.TabIndex = 28;
			chcopera.Text = "Opera";
			chcopera.UseVisualStyleBackColor = true;
			chcopera.CheckedChanged += checkBox1_CheckedChanged;
			// 
			// chctropicana
			// 
			chctropicana.AutoSize = true;
			chctropicana.Location = new Point(693, 144);
			chctropicana.Name = "chctropicana";
			chctropicana.Size = new Size(78, 19);
			chctropicana.TabIndex = 29;
			chctropicana.Text = "Tropicana";
			chctropicana.UseVisualStyleBackColor = true;
			// 
			// chcamericano
			// 
			chcamericano.AutoSize = true;
			chcamericano.Location = new Point(610, 170);
			chcamericano.Name = "chcamericano";
			chcamericano.Size = new Size(84, 19);
			chcamericano.TabIndex = 30;
			chcamericano.Text = "Americano";
			chcamericano.UseVisualStyleBackColor = true;
			// 
			// chcjupe
			// 
			chcjupe.AutoSize = true;
			chcjupe.Location = new Point(693, 170);
			chcjupe.Name = "chcjupe";
			chcjupe.Size = new Size(89, 19);
			chcjupe.TabIndex = 31;
			chcjupe.Text = "Jupe special";
			chcjupe.UseVisualStyleBackColor = true;
			// 
			// label6
			// 
			label6.AutoSize = true;
			label6.Location = new Point(646, 101);
			label6.Name = "label6";
			label6.Size = new Size(70, 15);
			label6.TabIndex = 32;
			label6.Text = "Lisätäytteet:";
			// 
			// chcpekoni
			// 
			chcpekoni.AutoSize = true;
			chcpekoni.Location = new Point(646, 217);
			chcpekoni.Name = "chcpekoni";
			chcpekoni.Size = new Size(77, 19);
			chcpekoni.TabIndex = 33;
			chcpekoni.Text = "Pekoni 2€";
			chcpekoni.UseVisualStyleBackColor = true;
			// 
			// chcKebab
			// 
			chcKebab.AutoSize = true;
			chcKebab.Location = new Point(646, 242);
			chcKebab.Name = "chcKebab";
			chcKebab.Size = new Size(74, 19);
			chcKebab.TabIndex = 35;
			chcKebab.Text = "Kebab 3€";
			chcKebab.UseVisualStyleBackColor = true;
			// 
			// txthinta
			// 
			txthinta.Location = new Point(840, 142);
			txthinta.Name = "txthinta";
			txthinta.Size = new Size(100, 23);
			txthinta.TabIndex = 36;
			// 
			// button1
			// 
			button1.Location = new Point(853, 180);
			button1.Name = "button1";
			button1.Size = new Size(54, 23);
			button1.TabIndex = 37;
			button1.Text = "Ok";
			button1.UseVisualStyleBackColor = true;
			button1.Click += button1_Click;
			// 
			// button2
			// 
			button2.Location = new Point(853, 209);
			button2.Name = "button2";
			button2.Size = new Size(54, 23);
			button2.TabIndex = 38;
			button2.Text = "Nollaa";
			button2.UseVisualStyleBackColor = true;
			button2.Click += button2_Click;
			// 
			// pictureBox1
			// 
			pictureBox1.Image = Properties.Resources.lataus__2_;
			pictureBox1.Location = new Point(788, 0);
			pictureBox1.Name = "pictureBox1";
			pictureBox1.Size = new Size(213, 116);
			pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
			pictureBox1.TabIndex = 39;
			pictureBox1.TabStop = false;
			// 
			// label11
			// 
			label11.AutoSize = true;
			label11.Location = new Point(853, 124);
			label11.Name = "label11";
			label11.Size = new Size(39, 15);
			label11.TabIndex = 40;
			label11.Text = "Hinta:";
			// 
			// txtKateinen
			// 
			txtKateinen.Location = new Point(716, 308);
			txtKateinen.Name = "txtKateinen";
			txtKateinen.Size = new Size(100, 23);
			txtKateinen.TabIndex = 41;
			// 
			// txtRahaaTakaisin
			// 
			txtRahaaTakaisin.Location = new Point(822, 308);
			txtRahaaTakaisin.Name = "txtRahaaTakaisin";
			txtRahaaTakaisin.Size = new Size(100, 23);
			txtRahaaTakaisin.TabIndex = 42;
			// 
			// label13
			// 
			label13.AutoSize = true;
			label13.Location = new Point(822, 287);
			label13.Name = "label13";
			label13.Size = new Size(85, 15);
			label13.TabIndex = 44;
			label13.Text = "Rahaa takaisin:";
			// 
			// chckateinen
			// 
			chckateinen.AutoSize = true;
			chckateinen.Location = new Point(716, 286);
			chckateinen.Name = "chckateinen";
			chckateinen.Size = new Size(75, 19);
			chckateinen.TabIndex = 45;
			chckateinen.Text = "Käteinen:";
			chckateinen.UseVisualStyleBackColor = true;
			// 
			// pictureBox2
			// 
			pictureBox2.Image = Properties.Resources.lataus__3_;
			pictureBox2.Location = new Point(434, 230);
			pictureBox2.Name = "pictureBox2";
			pictureBox2.Size = new Size(74, 101);
			pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
			pictureBox2.TabIndex = 46;
			pictureBox2.TabStop = false;
			// 
			// pictureBox3
			// 
			pictureBox3.Image = Properties.Resources.lataus__4_;
			pictureBox3.Location = new Point(493, 230);
			pictureBox3.Name = "pictureBox3";
			pictureBox3.Size = new Size(121, 107);
			pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
			pictureBox3.TabIndex = 47;
			pictureBox3.TabStop = false;
			// 
			// pictureBox4
			// 
			pictureBox4.Image = Properties.Resources.lataus__5_;
			pictureBox4.Location = new Point(-2, -3);
			pictureBox4.Name = "pictureBox4";
			pictureBox4.Size = new Size(184, 127);
			pictureBox4.SizeMode = PictureBoxSizeMode.Zoom;
			pictureBox4.TabIndex = 48;
			pictureBox4.TabStop = false;
			// 
			// pictureBox5
			// 
			pictureBox5.Image = Properties.Resources.lataus__6_;
			pictureBox5.Location = new Point(357, -3);
			pictureBox5.Name = "pictureBox5";
			pictureBox5.Size = new Size(167, 118);
			pictureBox5.SizeMode = PictureBoxSizeMode.Zoom;
			pictureBox5.TabIndex = 49;
			pictureBox5.TabStop = false;
			// 
			// txtKassa
			// 
			txtKassa.Location = new Point(928, 308);
			txtKassa.Name = "txtKassa";
			txtKassa.Size = new Size(100, 23);
			txtKassa.TabIndex = 50;
			// 
			// label12
			// 
			label12.AutoSize = true;
			label12.Location = new Point(928, 288);
			label12.Name = "label12";
			label12.Size = new Size(39, 15);
			label12.TabIndex = 51;
			label12.Text = "Kassa:";
			// 
			// button3
			// 
			button3.Location = new Point(835, 242);
			button3.Name = "button3";
			button3.Size = new Size(87, 23);
			button3.TabIndex = 52;
			button3.Text = "Nollaa kassa";
			button3.UseVisualStyleBackColor = true;
			button3.Click += button3_Click;
			// 
			// txtKuitti
			// 
			txtKuitti.Location = new Point(1067, 115);
			txtKuitti.Multiline = true;
			txtKuitti.Name = "txtKuitti";
			txtKuitti.Size = new Size(191, 216);
			txtKuitti.TabIndex = 53;
			// 
			// button4
			// 
			button4.Location = new Point(1146, 86);
			button4.Name = "button4";
			button4.Size = new Size(112, 23);
			button4.TabIndex = 54;
			button4.Text = "Nollaa historia";
			button4.UseVisualStyleBackColor = true;
			button4.Click += button4_Click;
			// 
			// label14
			// 
			label14.AutoSize = true;
			label14.Location = new Point(1060, 90);
			label14.Name = "label14";
			label14.Size = new Size(80, 15);
			label14.TabIndex = 55;
			label14.Text = "Tilaushistoria:";
			// 
			// pictureBox6
			// 
			pictureBox6.Image = Properties.Resources.lataus__7_;
			pictureBox6.Location = new Point(1128, 0);
			pictureBox6.Name = "pictureBox6";
			pictureBox6.Size = new Size(226, 80);
			pictureBox6.SizeMode = PictureBoxSizeMode.Zoom;
			pictureBox6.TabIndex = 56;
			pictureBox6.TabStop = false;
			// 
			// pictureBox7
			// 
			pictureBox7.Image = Properties.Resources.images;
			pictureBox7.Location = new Point(-62, 230);
			pictureBox7.Name = "pictureBox7";
			pictureBox7.Size = new Size(230, 144);
			pictureBox7.SizeMode = PictureBoxSizeMode.Zoom;
			pictureBox7.TabIndex = 57;
			pictureBox7.TabStop = false;
			// 
			// pictureBox8
			// 
			pictureBox8.Image = Properties.Resources.lataus__8_;
			pictureBox8.Location = new Point(1228, 230);
			pictureBox8.Name = "pictureBox8";
			pictureBox8.Size = new Size(126, 107);
			pictureBox8.SizeMode = PictureBoxSizeMode.Zoom;
			pictureBox8.TabIndex = 58;
			pictureBox8.TabStop = false;
			// 
			// label15
			// 
			label15.AutoSize = true;
			label15.Font = new Font("Segoe UI Black", 27.75F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
			label15.Location = new Point(146, 21);
			label15.Name = "label15";
			label15.Size = new Size(236, 50);
			label15.TabIndex = 59;
			label15.Text = "MARIZELLA";
			// 
			// Form1
			// 
			AutoScaleDimensions = new SizeF(7F, 15F);
			AutoScaleMode = AutoScaleMode.Font;
			BackColor = SystemColors.Control;
			ClientSize = new Size(1330, 364);
			Controls.Add(label15);
			Controls.Add(pictureBox6);
			Controls.Add(label14);
			Controls.Add(button4);
			Controls.Add(txtKuitti);
			Controls.Add(button3);
			Controls.Add(label12);
			Controls.Add(txtKassa);
			Controls.Add(chckateinen);
			Controls.Add(label13);
			Controls.Add(txtRahaaTakaisin);
			Controls.Add(txtKateinen);
			Controls.Add(label11);
			Controls.Add(button2);
			Controls.Add(button1);
			Controls.Add(txthinta);
			Controls.Add(chcKebab);
			Controls.Add(chcpekoni);
			Controls.Add(label6);
			Controls.Add(chcjupe);
			Controls.Add(chcamericano);
			Controls.Add(chctropicana);
			Controls.Add(chcopera);
			Controls.Add(chcbolognese);
			Controls.Add(chcmargarita);
			Controls.Add(numericUpDown1);
			Controls.Add(label5);
			Controls.Add(numericPepsi);
			Controls.Add(label10);
			Controls.Add(label9);
			Controls.Add(numericjupecial);
			Controls.Add(label7);
			Controls.Add(numericAmericano);
			Controls.Add(label8);
			Controls.Add(numerictropicana);
			Controls.Add(label3);
			Controls.Add(numericopera);
			Controls.Add(label4);
			Controls.Add(numericbolognese);
			Controls.Add(label2);
			Controls.Add(numericmargarita);
			Controls.Add(label1);
			Controls.Add(pictureBox1);
			Controls.Add(pictureBox2);
			Controls.Add(pictureBox3);
			Controls.Add(pictureBox4);
			Controls.Add(pictureBox5);
			Controls.Add(pictureBox7);
			Controls.Add(pictureBox8);
			Name = "Form1";
			Text = "Pizzeria Marizella";
			((System.ComponentModel.ISupportInitialize)numericmargarita).EndInit();
			((System.ComponentModel.ISupportInitialize)numericbolognese).EndInit();
			((System.ComponentModel.ISupportInitialize)numerictropicana).EndInit();
			((System.ComponentModel.ISupportInitialize)numericopera).EndInit();
			((System.ComponentModel.ISupportInitialize)numericjupecial).EndInit();
			((System.ComponentModel.ISupportInitialize)numericAmericano).EndInit();
			((System.ComponentModel.ISupportInitialize)numericPepsi).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown1).EndInit();
			((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
			((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
			((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
			((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
			((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
			((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
			((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
			((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
			ResumeLayout(false);
			PerformLayout();
		}

		#endregion

		private Label label1;
		private NumericUpDown numericmargarita;
		private NumericUpDown numericbolognese;
		private Label label2;
		private NumericUpDown numerictropicana;
		private Label label3;
		private NumericUpDown numericopera;
		private Label label4;
		private NumericUpDown numericjupecial;
		private Label label7;
		private NumericUpDown numericAmericano;
		private Label label8;
		private Label label9;
		private Label label10;
		private NumericUpDown numericPepsi;
		private NumericUpDown numericUpDown1;
		private Label label5;
		private TextBox txtHinta;
		private CheckBox checkBox4;
		private CheckBox checkBox5;
		private CheckBox checkBox6;
		private CheckBox checkBox9;
		private CheckBox chcmargarita;
		private CheckBox chcbolognese;
		private CheckBox chcopera;
		private CheckBox chctropicana;
		private CheckBox chcamericano;
		private CheckBox chcjupe;
		private Label label6;
		private CheckBox checkBox2;
		private CheckBox chcpekoni;
		private CheckBox chcKebab;
		private TextBox txthinta;
		private Button button1;
		private Button button2;
		private PictureBox pictureBox1;
		private Label label11;
		private TextBox txtKateinen;
		private TextBox txtRahaaTakaisin;
		private Label label13;
		private CheckBox chckateinen;
		private PictureBox pictureBox2;
		private PictureBox pictureBox3;
		private PictureBox pictureBox4;
		private PictureBox pictureBox5;
		private TextBox txtKassa;
		private Label label12;
		private Button button3;
		private TextBox txtKuitti;
		private Button button4;
		private Label label14;
		private PictureBox pictureBox6;
		private PictureBox pictureBox7;
		private PictureBox pictureBox8;
		private Label label15;
	}
}
