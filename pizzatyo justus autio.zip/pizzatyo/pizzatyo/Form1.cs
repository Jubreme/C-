using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace pizzatyo
{
	public partial class Form1 : Form
	{

		public Form1()
		{
			InitializeComponent();
		}

		private void textBox1_TextChanged(object sender, EventArgs e)
		{

		}

		private void checkBox1_CheckedChanged(object sender, EventArgs e)
		{

		}
		double kassa = 0;
		private void button1_Click(object sender, EventArgs e)
		{
			try
			{
				double margarita = 12, bologense = 11, opera = 13, tropicana = 12.5, americano = 14, jupe = 15, pepsi = 6, coca = 6; // määritetään pizzojen hinnat
				double pekoni = 2, kebab = 3; // määritetään lisätäytteiden hinnat
				double summa = 0; // alustetaan summa
				txtKuitti.Clear(); // tyhjentää txtkuitti boxin
				txthinta.Clear(); // tyhjentää txthinta boxin
				double m = (double)numericmargarita.Value; // margarita määrä muutetaan arvoksi m
				double b = (double)numericbolognese.Value;//bolognese määrä muutetaan arvoksi b
				double o = (double)numericopera.Value; // jne..
				double t = (double)numerictropicana.Value;
				double a = (double)numericAmericano.Value;
				double j = (double)numericjupecial.Value;
				summa += margarita * m; // summa = margarita (12e) * numericupdown (määrä)
				summa += bologense * b; // summa = bolognese (11e) * numericupdown (määrä)
				summa += opera * o; //summa = opera special (13e) * numericupdown (määrä)
				summa += tropicana * t;//summa = tropicana (12.5e) * numericupdown (määrä)
				summa += americano * a;//summa = americano (14) * numericupdown (määrä)
				summa += jupe * j;//summa = jupe special (15) * numericupdown (määrä)
				summa += pepsi * (double)numericPepsi.Value; // valitaan juomat (hinta * numupdown)
				summa += coca * (double)numericUpDown1.Value;
				if (chcpekoni.Checked) // jos lisätäyte pekoni on valittu
				{
					summa += pekoni; // lisätään pekonin hinta summaan
				}
				if (chcKebab.Checked)// jos lisätäyte kebabbi on valittu
				{
					summa += kebab;// lisätään kebabin hinta summaan
				}
				bool lisatäyteValittu = chcpekoni.Checked || chcKebab.Checked;// bool on true jos joko pekoni‑checkbox tai kebab‑checkbox on valittu
				if (lisatäyteValittu) 
				{
					if (chcmargarita.Checked && m == 0) // jos margarita lisätäyte on valittu mutta pizza ei ole valittu
					{
						MessageBox.Show("Et voi lisätä täytettä Margaritaan, koska sitä ei ole valittu."); // tulostaa viestin
						return;
					}
					if (chcbolognese.Checked && b == 0) // jos bolognese lisätäyte on valittu mutta pizza ei ole valittu
					{
						MessageBox.Show("Et voi lisätä täytettä Bologneseen, koska sitä ei ole valittu.");// tulostaa viestin
						return;
					}
					if (chcopera.Checked && o == 0) // jos opera lisätäyte on valittu mutta pizza ei ole valittu
					{
						MessageBox.Show("Et voi lisätä täytettä Operaan, koska sitä ei ole valittu."); // tulostaa viestin
						return;
					}
					if (chctropicana.Checked && t == 0) // jos tropicana lisätäyte on valittu mutta pizza ei ole valittu
					{
						MessageBox.Show("Et voi lisätä täytettä Tropicanaan, koska sitä ei ole valittu."); // tulostaa viestin
						return;
					}
					if (chcamericano.Checked && a == 0) // jos americano lisätäyte on valittu mutta pizza ei ole valittu
					{
						MessageBox.Show("Et voi lisätä täytettä Americanoon, koska sitä ei ole valittu."); // tulostaa viestin
						return;
					}
					if (chcjupe.Checked && j == 0) // jos jupe special lisätäyte on valittu mutta pizza ei ole valittu
					{
						MessageBox.Show("Et voi lisätä täytettä Jupe specialiin, koska sitä ei ole valittu."); // tulostaa viestin
						return;
					}
				}
				if (m > 0) // jos margarita pizzaa on tilattu
				{
					txtKuitti.AppendText($"Margarita x{m} = {margarita * m}" + "€" + Environment.NewLine); // tulostaa kuitin txtkuitti tekstiboxiin pizzan * määrän. Environment.NewLine lisää uuden rivin
				}
				if (b > 0)// jos bolognese pizzaa on tilattu
				{
					txtKuitti.AppendText($"Bolognese x{b} = {bologense * b}" + "€" + Environment.NewLine);// tulostaa kuitin txtkuitti tekstiboxiin. Environment.NewLine lisää uuden rivin
				}

				if (o > 0)// jos opera special pizzaa on tilattu
				{
					txtKuitti.AppendText($"Opera x{o} = {opera * o}" + "€" + Environment.NewLine);// tulostaa kuitin txtkuitti tekstiboxiin pizzan * määrän. Environment.NewLine lisää uuden rivin
				}
				if (t > 0)// jos tropicana pizzaa on tilattu
				{
					txtKuitti.AppendText($"Tropicana x{t} = {tropicana * t}" + "€" + Environment.NewLine);// tulostaa kuitin txtkuitti tekstiboxiin pizzan * määrän. Environment.NewLine lisää uuden rivin
				}
				if (a > 0)// jos americano pizzaa on tilattu
				{
					txtKuitti.AppendText($"Americano x{a} = {americano * a}" + "€" + Environment.NewLine);// tulostaa kuitin txtkuitti tekstiboxiin pizzan * määrän. Environment.NewLine lisää uuden rivin
				}
				if (j > 0)// jos jupe special pizzaa on tilattu
				{
					txtKuitti.AppendText($"Jupe Special x{j} = {jupe * j}" + "€" + Environment.NewLine);// tulostaa kuitin txtkuitti tekstiboxiin pizzan * määrän. Environment.NewLine lisää uuden rivin
				}
				if (numericPepsi.Value > 0) // jos pepsimax on valittu
				{
					txtKuitti.AppendText($"Pepsi x{numericPepsi.Value} = {pepsi * (double)numericPepsi.Value}" + "€" + Environment.NewLine); // tulostaa kuittiin pepsin hinnan * määrän
				}
				if (numericUpDown1.Value > 0) // jos cocacolaa on valittu
				{
					txtKuitti.AppendText($"Coca-Cola x{numericUpDown1.Value} = {coca * (double)numericUpDown1.Value}" + "€" + Environment.NewLine); // tulostaa kuittiin cocacolan hinnan * määrän
				}
				if (chcpekoni.Checked) // jos pekoni lisä täuyte valittu
				{
					if (chcmargarita.Checked)// jos margarittaan on valittu pekoni
					{
						txtKuitti.AppendText("Margarita lisätäyte: pekoni 2,00€" + Environment.NewLine); // tulostaa kuittiin viestin
					}

					if (chcbolognese.Checked) // jos bologneseen on valittu pekoni
					{
						txtKuitti.AppendText("Bolognese lisätäyte: pekoni 2,00€" + Environment.NewLine); 
					}

					if (chcopera.Checked) // jos opera on valittu pekoni
					{
						txtKuitti.AppendText("Opera lisätäyte: pekoni 2,00€" + Environment.NewLine);
					}

					if (chctropicana.Checked) // jos tropicana on valittu pekoni
					{
						txtKuitti.AppendText("Tropicana lisätäyte: pekoni 2,00€" + Environment.NewLine);
					}

					if (chcamericano.Checked) // jos americano on valittu pekoni
					{
						txtKuitti.AppendText("Americano lisätäyte: pekoni 2,00€" + Environment.NewLine);
					}

					if (chcjupe.Checked)// jos jupe sepcial on valittu pekoni
					{
						txtKuitti.AppendText("Jupe lisätäyte: pekoni 2,00€" + Environment.NewLine);
					}
				}
				if (chcKebab.Checked) // jos kebab lisäsätyte valittu
					{
					if (chcmargarita.Checked)// jos margarittaan on valittu kebab
					{
						txtKuitti.AppendText("Margarita lisätäyte: kebab 3,00€" + Environment.NewLine); // tulostaa kuittiin lisätäyteen + pizzan mihin se tulee
					}

					if (chcbolognese.Checked)// jos bologneseen on valittu kebab
					{
						txtKuitti.AppendText("Bolognese lisätäyte: kebab 3,00€" + Environment.NewLine); // tulostaa kuittiin lisätäyteen + pizzan mihin se tulee
					}

					if (chcopera.Checked)// jos opera on valittu kebab
					{
						txtKuitti.AppendText("Opera lisätäyte: kebab 3,00€" + Environment.NewLine); // tulostaa kuittiin lisätäyteen + pizzan mihin se tulee
					}

					if (chctropicana.Checked)// jos tropicana on valittu kebab
					{
						txtKuitti.AppendText("Tropicana lisätäyte: kebab 3,00€" + Environment.NewLine); // tulostaa kuittiin lisätäyteen + pizzan mihin se tulee
					}

					if (chcamericano.Checked) // jos americano on valittu kebab
					{
						txtKuitti.AppendText("Americano lisätäyte: kebab 3,00€" + Environment.NewLine); // tulostaa kuittiin lisätäyteen + pizzan mihin se tulee
					}

					if (chcjupe.Checked) // jos jupe on valittu kebab
					{
						txtKuitti.AppendText("Jupe lisätäyte: kebab 3,00€" + Environment.NewLine); // tulostaa kuittiin lisätäyteen + pizzan mihin se tulee
					}
				}
	

				if (chckateinen.Checked) // jos käteinen on valittu
				{
					double kateinen = double.Parse(txtKateinen.Text); // määritetään käteinen
					if (kateinen < 0) // jos käteisen määrä on pienempi kuin nolla
					{
						MessageBox.Show("Syötä käteisen määrä!"); // tulostaa viestin
						return;

					}
					if (kateinen < summa) // jos käteinen on pienempi kuin hinta
					{
	
						MessageBox.Show("rahat ei riitä"); // tulostaa viestin
						return;	
					}
					
					double rahaatakaisin = kateinen - summa; // tahaatakisin = käteinen - summa
					txtRahaaTakaisin.Text = rahaatakaisin.ToString("0.00") + " €";
					txtKuitti.AppendText($"Maksettu käteisellä: {kateinen:0.00}" + "€" + Environment.NewLine); // lisätään kuittiin käteismaksu. Environment.NewLine lisää uuden rivin
					txtKuitti.AppendText($"Rahaa takaisin: {rahaatakaisin:0.00}" + "€" + Environment.NewLine); // lisätään kuittiin rahaatakaisin. Environment.NewLine lisää uuden rivin
					kassa += summa;
					txtKassa.Text = kassa.ToString("0.00") + " €"; // tulostetaan kassan tulos
				}
				else // muuten
				{
					txthinta.Text = summa.ToString("0.00") + " €"; // tulostetaan hinta
					kassa += summa;
					txtKuitti.AppendText($"Maksettu kortilla: {summa:0.00}" + "€" + Environment.NewLine); // tulostaa kuittiin jos maksetaan kortilla
					txtKassa.Text = kassa.ToString("0.00") + " €";	
				}
				txthinta.Text = summa.ToString("0.00") + " €";
			}
			catch (Exception)
			{
				MessageBox.Show("Virhe"); // virhekoodi
			}
		}

		private void button2_Click(object sender, EventArgs e)
		{
			numericmargarita.Value = 0; // nollataan numericupdown
			numericbolognese.Value = 0; // nollataan numericupdown
			numericopera.Value = 0; // nollataan numericupdown
			numerictropicana.Value = 0; // nollataan numericupdown
			numericAmericano.Value = 0; // nollataan numericupdown
			numericjupecial.Value = 0; // nollataan numericupdown
			numericPepsi.Value = 0; // nollataan numericupdown
			numericUpDown1.Value = 0; // nollataan numericupdown
			chcpekoni.Checked = false; // nollataan checkboxit
			chcKebab.Checked = false;// nollataan checkboxit
			chckateinen.Checked = false;// nollataan checkboxit
			chcmargarita.Checked = false; // nollataan checkboxit
			chcbolognese.Checked = false; // nollataan checkboxit
			chctropicana.Checked = false; // nollataan checkboxit
			chcamericano.Checked = false; // nollataan checkboxit
			chcjupe.Checked = false; // nollataan checkboxit
			chcopera.Checked = false; // nollataan checkboxit
			txthinta.Clear(); // tyhjennetään tekstiboxit
			txtRahaaTakaisin.Clear(); // tyhjennetään tekstiboxit
			txtKateinen.Clear(); // tyhjennetään tekstiboxit
		}

		private void button3_Click(object sender, EventArgs e)
		{
			txtKassa.Clear(); // nollaa kassa tekstiboxi
		}

		private void button4_Click(object sender, EventArgs e)
		{
			txtKuitti.Clear(); // nollataan kuitti tekstiboxi
		}
	}
}
